1. Change the Connection String in appsettings.json
You need to update the connection string in the appsettings.json file to point to the correct database. If you're using a file named EmployeeManagementConnectionString, it should look something like this:

2. Open the Package Manager Console
To run the migration commands, you need to open the Package Manager Console in Visual Studio:

Go to Tools in the top menu.
Select NuGet Package Manager.
Click on Package Manager Console.

3. Run add-migration InitialMigration Command

4. Migration File
After running the command, the Migrations folder in your solution will have a new file created (the name will reflect the migration name you specified, e.g., 20241220123456_InitialMigration.cs).

This migration file contains the instructions for creating the necessary database tables and structures.

Replace the below code in the up and down function

 protected override void Up(MigrationBuilder migrationBuilder)
 {
     migrationBuilder.CreateTable(
         name: "Employees",
         columns: table => new
         {
             Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
             Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
             Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
             Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
             Salary = table.Column<double>(type: "float", nullable: false),
             Department = table.Column<string>(type: "nvarchar(max)", nullable: true)
         },
         constraints: table =>
         {
             table.PrimaryKey("PK_Employees", x => x.Id);
         });
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
     migrationBuilder.DropTable(
         name: "Employees");
 }

5. Applying the Migration
Run update-database