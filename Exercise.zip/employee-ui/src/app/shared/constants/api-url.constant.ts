export const BASE_URL = 'https://localhost:7035/api/';

export const API_URL = {
   employee: BASE_URL + 'Employees',
};