export interface EMPLOYEE {
    name: string,
    country: string,
    skills: string[],
    proficiency: number,
    mobile: number,
    email: string
}