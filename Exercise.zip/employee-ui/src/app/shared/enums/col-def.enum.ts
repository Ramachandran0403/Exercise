export enum COLUMN_HEADER {
    NAME = 'Name',
    COUNTRY = 'Country',
    SKILLS = 'Skills',
    PROFICIENCY = 'Proficiency',
    MOBILE = 'Mobile',
    EMAIL = 'Email',
    ACTION = 'Action'
}