export enum SKILLS {
    HTML = 'HTML',
    CSS = 'CSS',
    JS = 'JS',
}
